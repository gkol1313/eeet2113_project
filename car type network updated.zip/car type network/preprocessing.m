%% Download datasets
% This script will require 'pip install kagglehub'
insert(py.sys.path, int32(0), 'download_data.py');

% Call the Python function
py_result = py.download_data.download_datasets();

% Convert Python dictionary to MATLAB structure
matlab_paths.colour_classification = char(py_result{'colour_classification'});
matlab_paths.license_plate_chars = char(py_result{'license_plate_chars'});
matlab_paths.license_plate_segmentation = char(py_result{'license_plate_segmentation'});
matlab_paths.car_type = char(py_result{'car_type'});

% Assign paths to different data sections


% This does not have distinct training and testing data, needs to be
% separated.
license_plate_chars_path = matlab_paths.license_plate_chars;

% This does not have distinct training and testing data, needs to be
% separated.
license_plate_segmentation_path = matlab_paths.license_plate_segmentation;

% Assign paths to different data sections
car_type_root = matlab_paths.car_type;
car_type_test = car_type_root + "\Cars_Body_Type\test";
car_type_train = car_type_root + "\Cars_Body_Type\train";
car_type_val = car_type_root + "\Cars_Body_Type\valid";

% Display the root paths to each data set
disp(['License Plate Characters Path: ', license_plate_chars_path]);
disp(['License Plate Segmentation Path: ', license_plate_segmentation_path]);
disp(['Car Type Path: ', car_type_root]);

%%  Preprocessing
% Define output directories for preprocessed images
preprocessed_root = fullfile(pwd, 'preprocessed_data');
if ~exist(preprocessed_root, 'dir')
    mkdir(preprocessed_root);
end

% Function to process and store images
% This function sets labels based on the immediate parent directory of the file being stored in the datastore.
% Not every dataset fits this format, and hence this function isn't guaranteed to work for all datasets.
% Will work for: 
% - Colour Classification Dataset
% - Car Type Dataset
% Will not work for:
% - License Plate Characters/Segmentation
function datastoreObj = preprocess_and_store_images(input_path, output_path, convert_gray)
    % Create output folder if it doesn't exist
    if ~exist(output_path, 'dir')
        mkdir(output_path);
    end

    % Create an imageDatastore for input images
    imgDS = imageDatastore(input_path, 'IncludeSubfolders', true, 'LabelSource', 'foldernames');

    % Process each image
    for i = 1:numel(imgDS.Files)
        img_path = imgDS.Files{i};
        img = imread(img_path);                 % Read image
        img = imresize(img, [224 224]);         % Resize for ResNet-50



        % Convert to grayscale if required
        if convert_gray && size(img, 3) == 3
            img = rgb2gray(img);
        end
% normalise the data
        img = double(img) / 255;               % Scale [0, 255] to [0, 1]
        img = img - 0.5;                       % Shift range to [-0.5, 0.5]
        img = img * 2;  

        % Apply texture sharpening
        %img = imsharpen(img, 'Radius', 1, 'Amount', 1); % Conservative edge enhancement

        % Get relative path from input_path
        relative_path = strrep(img_path, [input_path filesep], '');
        relative_path = relative_path{1};

        % Extract folder and file name
        [subfolder, name, ext] = fileparts(relative_path);

        % Build full output folder path
        full_output_folder = fullfile(output_path, subfolder);
        if ~exist(full_output_folder, 'dir')
            mkdir(full_output_folder);
        end

        % Save processed image
        output_file = fullfile(full_output_folder, [name, ext]);
        imwrite(img, output_file);
    end

    % Return new imageDatastore with processed images
    datastoreObj = imageDatastore(output_path, 'IncludeSubfolders', true, 'LabelSource', 'foldernames');
end

% These license plate data sets need to use a new function which maps annotations contained in
% .xml files to corresponding images, rather than just setting labels based on filename.
% license_plate_chars_DS = preprocess_and_store_images(license_plate_chars_path, fullfile(preprocessed_root, 'license_plate_chars'), true);
% license_plate_segmentation_DS = preprocess_and_store_images(license_plate_segmentation_path, fullfile(preprocessed_root, 'license_plate_segmentation'), true);

car_type_train_DS = preprocess_and_store_images(car_type_train, fullfile(preprocessed_root, 'car_type_train'), false);
car_type_test_DS = preprocess_and_store_images(car_type_test, fullfile(preprocessed_root, 'car_type_test'), false);
car_type_val_DS = preprocess_and_store_images(car_type_val, fullfile(preprocessed_root, 'car_type_val'), false);

% Display message indicating preprocessing is complete
disp('Preprocessing complete. Processed imageDatastore objects are ready.');

%% Train the Colour Classifier
classNames = categories(car_type_train_DS.Labels);
%Need to check how these have been set
disp(classNames);
numClasses = numel(classNames);

net = imagePretrainedNetwork("resnet18", NumClasses=numClasses);
net = setLearnRateFactor(net, "fc1000/Weights",10);
net = setLearnRateFactor(net, "fc1000/Bias",10);

analyzeNetwork(net)

options = trainingOptions('sgdm', ...
                          'MiniBatchSize',8, ...
                          'MaxEpochs',12, ...
                          'InitialLearnRate',1e-3, ...
                          'LearnRateSchedule', 'piecewise', ...
                          'LearnRateDropFactor', 0.1, ...
                          'LearnRateDropPeriod', 5, ...
                          'Shuffle','every-epoch', ...
                          'ValidationData',car_type_val_DS, ...
                          'ValidationFrequency',10, ...
                          'Verbose',false, ...
                          'Metrics',"accuracy", ...
                          'Plots','training-progress', ...
                          'L2Regularization', 1e-4);
layers = net.Layers;

% Adding dropout before the fully connected layer
% Find the last convolutional layer
convLayerIdx = find(arrayfun(@(x) isa(x, 'nnet.cnn.layer.Convolution2DLayer'), layers), 1, 'last');

% Get the layers after the last convolutional layer
newLayers = layers(convLayerIdx+1:end);

% Add dropout before the fully connected layers
newLayers = [
    newLayers(1:end-3)         % Retain all layers before the fully connected part
    dropoutLayer(0.5)          % Add dropout with 50% dropout rate
    fullyConnectedLayer(numClasses)
    softmaxLayer
    classificationLayer
];

net = trainnet(car_type_train_DS, net, "crossentropy", options);
car_type_net = net;
save ('trainedCarType.m','car_type_net')
%% Test the Network

XTest = readall(car_type_test_DS);
TTest = car_type_test_DS.Labels;
classNames = categories(TTest);

XTest = cat(4,XTest{:});
XTest = single(XTest);

YTest = minibatchpredict(net,XTest);
YTest = onehotdecode(YTest,classNames,2);

% Generate confusion chart
confusionchart(TTest,YTest)

% Generate average accuracy metric
accuracy = mean(YTest == TTest)

